/* Id          : 6306021621073
*  Name        : Mr. Thanaphoom Arunchit
*  Room        : 1 RB
*  File Name   : Point.java
*/

public class Point {

    protected int x1, y1, x2, y2;
    public static String text = "Line";

    // set data to x1
    public void setX1(int x1) {
        this.x1 = x1;
    }

    // set data to y1
    public void setY1(int y1) {
        this.y1 = y1;
    }

    // set data to x2
    public void setX2(int x2) {
        this.x2 = x2;
    }

    // set data to y2
    public void setY2(int y2) {
        this.y2 = y2;
    }

} 