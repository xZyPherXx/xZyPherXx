/* Id          : 6306021621073
*  Name        : Mr. Thanaphoom Arunchit
*  Room        : 1 RB
*  File Name   : Line.java
*/

import java.awt.Graphics;

public class Line extends Point {

    // draw
    public void Draw(Graphics g) {
        g.drawLine(this.x1, this.y1, this.x2, this.y2);
    }

}