/* Id          : 6306021621073
*  Name        : Mr. Thanaphoom Arunchit
*  Room        : 1 RB
*  File Name   : Rectangle.java
*/

import java.awt.Graphics;

public class Rectangle extends Point {

    // Draw
    public void Draw(Graphics g) {
        g.drawRect(this.x1, this.y1, this.x2 - this.x1, this.y2 - this.y1);
    }


}