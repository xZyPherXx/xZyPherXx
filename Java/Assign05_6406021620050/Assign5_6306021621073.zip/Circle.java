/* Id          : 6306021621073
*  Name        : Mr. Thanaphoom Arunchit
*  Room        : 1 RB
*  File Name   : Circle.java
*/

import java.awt.Graphics;

public class Circle extends Point {

    private int size;

    // set data to x2
    @Override
    public void setX2(int x2) {
        this.x2 = x2;
        this.size = Math.abs(this.x2 - this.x1);
    }

    // Draw
    public void Draw(Graphics g) {
        g.drawOval(this.x1 - this.size, this.y1 - this.size, this.size * 2, this.size * 2);        
    }
}