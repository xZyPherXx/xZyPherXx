/* Id          : 6306021621073
*  Name        : Mr. Thanaphoom Arunchit
*  Room        : 1 RB
*  File Name   : Assign05_Paint.java
*/

import javax.swing.JFrame;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.Graphics;
import java.awt.Font;
import java.awt.Color;

public class Assign05_Paint extends JFrame implements KeyListener, MouseListener, MouseMotionListener{

    private Container container = getContentPane();
    private int status = 76;
    private Line line = new Line();
    private Rectangle rect = new Rectangle();
    private Circle circle = new Circle();

    // Load UI
    private void loader() {

        // container seting
        this.container.setLayout(new FlowLayout());
    }

    // Contractor
    public Assign05_Paint() {

        // set title
        super("Demo Paint use Keyboard and Mouse");

        // call method loader
        this.loader();
        
        // action
        addKeyListener(this);
        addMouseListener(this);
        addMouseMotionListener(this);

        // seting window
        setFont(new Font("Arial", Font.BOLD, 20));
        setForeground(Color.BLUE);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setVisible(true);
    }

   // Java App
    public static void main(String[] args) {
        new Assign05_Paint();
    }


    // on key down
    public void keyPressed(KeyEvent e) {
        // check key
        switch(e.getKeyCode()) {
            // key code 76 = L
            case 76:
                Point.text = "Line";
                this.status = 76;
                break;
            // key code 76 = R
            case 82:
                Point.text = "Rectangle";
                this.status = 82;
                break;
            // key code 76 = C
            case 67:
                Point.text = "Circle";
                this.status = 67;
                break;
        }
        repaint();
    }

    // on key up
    public void keyReleased(KeyEvent e) { }

    // on key
    public void keyTyped(KeyEvent e) { }

    // on mouse move
    public void mouseMoved(MouseEvent e) { }

    // on mouse drage
    public void mouseDragged(MouseEvent e) {
        // check status
        switch(status) {
            case 76:
                this.line.setX2(e.getX());
                this.line.setY2(e.getY());
                break;
            case 82:
                this.rect.setX2(e.getX());
                this.rect.setY2(e.getY());
                break;
            case 67:
                this.circle.setX2(e.getX());
                this.circle.setY2(e.getY());
                break;
        }
        repaint();
    }

    // paint graphic
    public void paint(Graphics g) {
        super.paint(g);

        // paint text
        g.drawString("Shape : " + Point.text, 20, 50);

        // check status
        switch(status) {
            // keycode 76 = R
            case 76:
                line.Draw(g);
                break;
            // keycode 82 = L
            case 82:
                rect.Draw(g);
                break;
            // keycode 67 = C
            case 67:
                circle.Draw(g);
                break;
        }
    }

    // on mouse down
    public void mousePressed(MouseEvent e) {
        // check status
        switch(status) {
            case 76:
                this.line.setX1(e.getX());
                this.line.setY1(e.getY());
                break;
            case 82:
                this.rect.setX1(e.getX());
                this.rect.setY1(e.getY());
                break;
            case 67:
                this.circle.setX1(e.getX());
                this.circle.setY1(e.getY());
                break;
        }
    }

    // on mouse up
    public void mouseReleased(MouseEvent e) { }

    // on mouse enter
    public void mouseEntered(MouseEvent e) { }

    // on mouse exit
    public void mouseExited(MouseEvent e) { }

    // on mouse click
    public void mouseClicked(MouseEvent e) { }

}